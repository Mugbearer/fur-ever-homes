<?php

include_once("connection.php");

$adoptionID = $_GET["adoptionID"];
$status = $_GET["status"];
$petID = null;
$result = null;

if($status === "confirmed")
{
  $result = mysqli_query($con,"SELECT pet_id FROM adoptions WHERE adoption_id='$adoptionID'");
  if ($row = mysqli_fetch_array($result))
  {
    $petID = $row[0];
  }
  $result = mysqli_query($con, "UPDATE adoptions SET status='terminated' WHERE pet_id=$petID");
}

$result = mysqli_query($con, "UPDATE adoptions SET status='$status' WHERE adoption_id=$adoptionID");

echo "Adoption status updated";

?>