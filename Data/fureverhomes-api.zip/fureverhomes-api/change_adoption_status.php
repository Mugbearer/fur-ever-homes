<?php

include_once("connection.php");

$petID = $_GET["petID"];
$status = $_GET["status"];
$result = null;

if($status === "approved")
{
  $result = mysqli_query($con, "UPDATE pets SET status='terminated' WHERE pet_id=$petID");
  $result = mysqli_query($con, "UPDATE adoptions SET status='terminated' WHERE pet_id=$petID");
}
else
{
  $result = mysqli_query($con, "UPDATE adoptions SET status='$status' WHERE pet_id=$petID");
}

echo "Adoption status updated";

?>