<?php

include_once("connection.php");
$username = $_GET["username"];
$password = $_GET["password"];

$result = mysqli_query($con,"SELECT * FROM accounts WHERE username='$username'");

if (mysqli_num_rows($result) === 0)
{
  die("Username does not exist");
}

$accountData = [];
if ($row = mysqli_fetch_array($result))
{
  array_push($accountData,$row);
}

if ($password != $accountData[0][2])
{
  die("Invalid password");
}

echo json_encode($accountData);

?>