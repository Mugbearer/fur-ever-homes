<?php

include_once("connection.php");

$accountID = $_GET["accountID"];
$petIDs = [];

$result = mysqli_query($con,"SELECT pet_id FROM adoptions WHERE account_id=$accountID AND status='pending'");

while ($row = mysqli_fetch_array($result))
{
  array_push($petIDs,$row[0]);
}

$data = [];
foreach ($petIDs as $petID)
{
  $result = mysqli_query($con,"SELECT * FROM pets WHERE pet_id=$petID");
  if ($row = mysqli_fetch_array($result))
  {
    if ($row != null)
    {
      array_push($data,$row);
    }
  }
}

echo json_encode($data);

?>