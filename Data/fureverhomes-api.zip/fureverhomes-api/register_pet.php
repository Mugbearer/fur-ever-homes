<?php

include_once("connection.php");

$accountID = $_GET["accountID"];
$name = $_GET["name"];
$sex = $_GET["sex"];
$birthdate = $_GET["birthdate"];
$breed = $_GET["breed"];
$imageURL = $_GET["imageURL"];
$description = $_GET["description"];
$dateRegistered = date("Y/m/d");

$result = mysqli_query($con,"INSERT INTO pets (account_id,name,sex,birthdate,breed,image_url,description,date_registered,status) 
VALUES($accountID,'$name','$sex','$birthdate','$breed','$imageURL','$description','$dateRegistered','unconfirmed')");

echo "Pet Added";

?>