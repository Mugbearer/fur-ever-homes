<?php

include_once("connection.php");

$petID = $_GET["petID"];
$status = $_GET["status"];

$result = mysqli_query($con, "UPDATE pets SET status='$status' WHERE pet_id=$petID");

echo "Pet status changed";

?>