<?php

include_once("connection.php");
$username = $_GET["username"];
$password = $_GET["password"];
$firstName = $_GET["firstName"];
$lastName = $_GET["lastName"];
$emailAddress = $_GET["emailAddress"];
$contactNum = $_GET["contactNum"];
// $isAdmin = "false";

$emailResult = mysqli_query($con,"SELECT * FROM accounts WHERE email_address='$emailAddress'");
$usernameResult = mysqli_query($con,"SELECT * FROM accounts WHERE username='$username'");

if (mysqli_num_rows($emailResult) > 0 || mysqli_num_rows($usernameResult) > 0)
{
  $errorResponse = "";
  if (mysqli_num_rows($emailResult) > 0)
  {
    $errorResponse .= "Email is already taken";
  }
  if (mysqli_num_rows($usernameResult) > 0)
  {
    $errorResponse .= ";Username is already taken";
  }
  die(trim($errorResponse,";"));
}

$result = mysqli_query($con,"INSERT INTO accounts (username,password,first_name,last_name,contact_num,email_address,is_admin) 
VALUES('$username','$password','$firstName','$lastName','$contactNum','$emailAddress','false')");

echo "Register success";

?>