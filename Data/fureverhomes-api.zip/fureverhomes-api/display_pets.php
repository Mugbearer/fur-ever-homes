<?php

include_once("connection.php");

$accountID = $_GET["accountID"];
$status = $_GET["status"];
$data = [];

if ($accountID === "all")
{
  $result = mysqli_query($con,"SELECT * FROM pets WHERE status='$status'");
}

else
{
  $result = mysqli_query($con,"SELECT * FROM pets WHERE status='$status' AND account_id=$accountID");
}

while ($row = mysqli_fetch_array($result))
{
  array_push($data,$row);
}

echo json_encode($data);

?>