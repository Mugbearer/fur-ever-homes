<?php

include_once("connection.php");

$petID = $_GET["petID"];
$name = $_GET["name"];
$sex = $_GET["sex"];
$birthdate = $_GET["birthdate"];
$breed = $_GET["breed"];
$imageURL = $_GET["imageURL"];
$description = $_GET["description"];
$dateRegistered = $_GET["dateRegistered"];

// $result = mysqli_query($con,"UPDATE INTO pets (account_id,name,sex,birthdate,breed,image_url,description,date_registered,status) 
// VALUES($accountID,'$name','$sex','$birthdate','$breed','$imageURL','$description','$dateRegistered','unconfirmed')");

$result = mysqli_query($con, "UPDATE pets SET name='$name',sex='$sex',birthdate='$birthdate',breed='$breed',image_url='$imageURL',
description='$description',date_registered='$dateRegistered',status='unconfirmed' WHERE pet_id=$petID");

echo "Pet Added";

?>