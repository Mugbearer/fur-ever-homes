<?php

include_once("connection.php");

$petID = $_GET["petID"];
$accountID = $_GET["accountID"];
$date = date("Y/m/d");

$result = mysqli_query($con,"INSERT INTO adoptions (pet_id,account_id,date) VALUES($petID,$accountID,'$date')");

echo "Adoption request sent";

?>