<?php

include_once("connection.php");

$petID = $_GET["petID"];

$result = mysqli_query($con,"SELECT * FROM pets WHERE pet_id=$petID");

if (mysqli_num_rows($result) === 0)
{
  die("Pet ID Does Not Exist");
}

$result = mysqli_query($con,"DELETE FROM pets WHERE pet_id=$petID");

echo "Pet Deleted";

?>